<?php $__env->startSection('content'); ?>
   <div class="container">
    
        
     <style>
    .tit {
                text-align: center;
                font-size:25px;
            }
     </style>
     
     
      <h1 class=tit>Editar Producto</h1>

        <form action="<?php echo e(url('/producto/'.$datos->id)); ?>" method="post" enctype="multipart/form-data" >
               <?php echo csrf_field(); ?>
                 <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                    
                        
                            <div class="row form-group">
                                            <div class="col-3">
                                                <label for="nombre"> Nombre: </label>
                                            </div>
                                            <div class="col-9">
                                                <input  class="form-control" id="nombre" name="nombre" required=""value="<?php echo e($datos->nombre); ?>">
                                            </div>
                                        </div>
                          <div class="row form-group">
                                <div class="col-3">
                                    <label for="cantidad"> Cantidad </label>
                                </div>
                                <div class="col-9">
                                    <input type="number" class="form-control" id="cantidad" name="cantidad" min="0" required="" value="<?php echo e($datos->cantidad); ?>">
                                </div>
                            </div>
                            
                        </div>
                        <div class="row form-group">
                                <div class="col-3">
                                    <label for="precio"> Precio/Unitario </label>
                                </div>
                                <div class="col-9">
                                    <input type="number" step="0.01" class="form-control" id="precio" name="precio" required=""value="<?php echo e($datos->precio); ?>">
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-3">
                                    <label for="descripcion"> Descripción </label>
                                </div>
                                <div class="col-9">
                                    <textarea type="text" class="form-control" id="descripcion" name="descripcion" ><?php echo e($datos->descripcion); ?></textarea>
                                </div>
                            </div>

            <div class="form-group">
            <label for="file">Imagen </label>
            <input type="file" name="imagen" id="imagen" value="" accept="image/*"> 
                    <div class="form-label-group">
                    <img src=" <?php echo e(asset('storage').'/'.$datos->imagen); ?>" alt="" width="400"> 
                        
                    </div>
                    </div>

                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary"> Enviar </button>
                                    <a type="button" class="btn btn-danger" style="background-color:red"  href="<?php echo e(url('producto')); ?>"> Cancelar </a>
                                </div>
                            
                            </form>
                        
                </div>
                </div>
            </div>
        
        </div>
         
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/inventario/resources/views/productos/editar.blade.php ENDPATH**/ ?>