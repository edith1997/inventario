<?php $__env->startSection('content'); ?>

    <div class="container">
    
        
     <style>
    .tit {
                text-align: center;
                font-size:25px;
            }
     </style>
     
     
      <h1 class=tit>Productos Registrados</h1>
        <a href="#" data-toggle="modal" data-target="#modalregistro"class="float-right btn btn-success">Agregar producto</a><br/><br/>
        <table class="table table-light">
            <thead class="thead-light">
                <tr>
                    <th>PDF</th>
                    <th>Nombre</th>
                    <th>Cantidad</th>
                    <th>Precio/Unitario</th>
                    <th>Descripción</th>
                    <th>Imagen</th>
                    <th>Valor total</th>
                    <th>Eliminar</th>
                    <th>Editar</th>
             </tr>
            </thead>

            <tbody>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                  <td> <a href="<?php echo e(url('/producto/pdf/'.$producto->id)); ?>"class="btn btn-success "><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-arrow-down-circle-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 5a.5.5 0 0 0-1 0v4.793L5.354 7.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 9.793V5z"/>
</svg> </td>
                    <td><?php echo e($producto ->nombre); ?></td>
                    <td><?php echo e($producto->cantidad); ?></td>
                    <td><?php echo e($producto->precio); ?></td>
                    <td><?php echo e($producto->descripcion); ?></td>
                    <td><img src="<?php echo e(asset('storage').'/'.$producto->imagen); ?>" style="width:70%" ></td>
                    <td> <?php echo e($producto->total); ?></td>
                    <td> 
                          <form method="post" action="<?php echo e(url('/producto/'.$producto->id)); ?>">
                               <?php echo e(csrf_field()); ?>

                               <?php echo e(method_field('DELETE')); ?>

                              <button type="submit" class="btn btn-success " style="background-color:red" onclick="return confirm('¿Estas seguro de Borrar?');"><i class="material-icons">delete_forever</i></button>              
                           </form> 
                             
                    </td>
                    <td>
                    
                     <a class="btn btn-success" href="<?php echo e(url('/producto/'.$producto->id.'/edit')); ?>"><i class="material-icons">create</i></a> 
                    </td>
                   </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="row">
         <a  href="<?php echo e(route('exportar')); ?>"  class="btn btn-info" style="width: 200px">Exportar a CSV</a>  
        <div class="col-lg-12">
          
         
        
    </div>
        </div>
         
    </div>


        <div class="modal fade" id="modalregistro" tabindex="-1" role="dialog" >
         <div class="modal-dialog" >
                <div class="modal-content">
                
                    <div class="modal-header text-center">
                        <h5 class="modal-title text-center" id="exampleModalLabel"> Agregar Producto</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>


                    <form  method="post" enctype="multipart/form-data" action="<?php echo e(route('producto.store')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="modal-body">
                            <div class="row form-group">
                                <div class="col-3">
                                    <label for="nombre"> Nombre: </label>
                                </div>
                                <div class="col-9">
                                    <input  class="form-control" id="nombre" name="nombre" required="">
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-3">
                                    <label for="cantidad"> Cantidad </label>
                                </div>
                                <div class="col-9">
                                    <input type="number" class="form-control" id="cantidad" name="cantidad" min="0" required="">
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-3">
                                    <label for="precio"> Precio/Unitario </label>
                                </div>
                                <div class="col-9">
                                    <input type="number" step="0.01" class="form-control" id="precio" name="precio" required="">
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-3">
                                    <label for="descripcion"> Descripción </label>
                                </div>
                                <div class="col-9">
                                    <textarea type="text" class="form-control" id="descripcion" name="descripcion" ></textarea>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-3">
                                    <label for="imagen"> Imagen</label>
                                </div>
                                <div class="col-9">
                                    <input type="file" name="imagen" id="imagen" accept="image/*">
                                </div>
                            </div>
                            
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" style="background-color:red"  data-dismiss="modal"> Cancelar </button></br>
                        <button type="submit" class="btn btn-primary"> Aceptar </button>
                    </div>
                    </form>
                </div> 
            </div>
            
        </div>
</div>        
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/inventario/resources/views/productos/index.blade.php ENDPATH**/ ?>