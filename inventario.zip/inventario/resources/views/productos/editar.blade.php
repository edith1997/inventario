@extends('layouts.app2')
@section('content')
   <div class="container">
    
        {{-- <a href="{{ url('user/create') }}"class="btn btn-success">Agregar Usuario</a> --}}
     <style>
    .tit {
                text-align: center;
                font-size:25px;
            }
     </style>
     
     
      <h1 class=tit>Editar Producto</h1>

        <form action="{{ url('/producto/'.$datos->id)}}" method="post" enctype="multipart/form-data" >
               @csrf
                 @method('PUT')
                    <div class="form-group">
                    {{-- numero de control --}}
                        
                            <div class="row form-group">
                                            <div class="col-3">
                                                <label for="nombre"> Nombre: </label>
                                            </div>
                                            <div class="col-9">
                                                <input  class="form-control" id="nombre" name="nombre" required=""value="{{$datos->nombre}}">
                                            </div>
                                        </div>
                          <div class="row form-group">
                                <div class="col-3">
                                    <label for="cantidad"> Cantidad </label>
                                </div>
                                <div class="col-9">
                                    <input type="number" class="form-control" id="cantidad" name="cantidad" min="0" required="" value="{{$datos->cantidad}}">
                                </div>
                            </div>
                            
                        </div>
                        <div class="row form-group">
                                <div class="col-3">
                                    <label for="precio"> Precio/Unitario </label>
                                </div>
                                <div class="col-9">
                                    <input type="number" step="0.01" class="form-control" id="precio" name="precio" required=""value="{{$datos->precio}}">
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-3">
                                    <label for="descripcion"> Descripción </label>
                                </div>
                                <div class="col-9">
                                    <textarea type="text" class="form-control" id="descripcion" name="descripcion" >{{$datos->descripcion}}</textarea>
                                </div>
                            </div>

            <div class="form-group">
            <label for="file">Imagen </label>
            <input type="file" name="imagen" id="imagen" value="" accept="image/*"> 
                    <div class="form-label-group">
                    <img src=" {{ asset('storage').'/'.$datos->imagen}}" alt="" width="400"> 
                        
                    </div>
                    </div>

                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary"> Enviar </button>
                                    <a type="button" class="btn btn-danger" style="background-color:red"  href="{{ url('producto')}}"> Cancelar </a>
                                </div>
                            
                            </form>
                        
                </div>
                </div>
            </div>
        
        </div>
         {{-- <a style="background-color:blue" href="{{ url('paciente') }}"class="btn btn-success">Mis Pacientes</a> --}}
    </div>
@endsection