<?php

namespace App\Http\Controllers;

use App\Producto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Barryvdh\DomPDF\Facade as PDF;
class ProductoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $productos=Producto::paginate(6);
        return view('productos.index',compact('productos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    public function create_pdf($id){
        $productos=Producto::findOrFail($id);
        // dd($productos);
        $pdf=PDF::loadView('productos.productospdf',compact('productos'));  
        return $pdf->stream();
     
      }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $datos=request()->except('_token');
       
        if($request->hasFile('imagen')){
          
            $datos['imagen']=$request->file('imagen')->store('/','public');

         }
         $datos['total']=$datos['cantidad']*$datos['precio'];
         Producto::insert($datos);
         return redirect()->route('producto.index')->with('Success','Elementos guardados'); 
    
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Producto  $producto
     * @return \Illuminate\Http\Response
     */
    public function show(Producto $producto)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Producto  $producto
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $datos=Producto::findOrFail($id);
        return view('productos.editar',compact('datos'));
       
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Producto  $producto
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $datos=request()->except(['_token','_method']);
        if($request->hasFile('imagen')){
            $producto=Producto::findOrFail($id);
            Storage::delete('public/'.$producto->imagen);

            $datos['imagen']=$request->file('imagen')->store('/','public');
         }
         $datos['total']=$datos['cantidad']*$datos['precio'];
         Producto::where('id','=',$id)->update($datos);
       
        return redirect('producto');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Producto  $producto
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $productos=Producto::findOrFail($id);
        if(Storage::delete('public/'.$productos->imagen)){
            Producto::destroy($id);
        }
       
        return redirect()->route('producto.index');

       
    }
}
