<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::resource('/', 'ProductoController');
Route::resource('producto', 'ProductoController');
Route::get('csv', function(){
    $n= DB::table('productos')
    ->select('*')
     ->get();
     $filename = "inventario.csv";
     $handle = fopen($filename, 'w+');
     fputcsv($handle, array('nombre', 'cantidad','precio','descripcion','valor total'));
     foreach($n as $row) {
         fputcsv($handle, array( $row->nombre,$row->cantidad,$row->precio,$row->descripcion,$row->total));
     }
     fclose($handle);
 
     $headers = array(
         'Content-Type' => 'text/csv',
     );
 
  return Response::download($filename, 'inventario.csv', $headers);

 })->name('exportar');
 Route::get('producto/destroy/{id}', 'ProductoController@destroy')->name('producto.destroy');
Route::get('producto/pdf/{id}','ProductoController@create_pdf')->name('producto.pdf');